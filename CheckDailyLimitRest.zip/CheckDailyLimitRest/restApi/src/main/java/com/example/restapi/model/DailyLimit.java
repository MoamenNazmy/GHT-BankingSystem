package com.example.restapi.model;

import javax.persistence.*;

@Entity
@Table(name = "transferdaily")
public class DailyLimit {

    @Id
    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name = "transfer_daily_limit")
    private Integer transferDailyLimit;

    // Getters and setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getTransferDailyLimit() {
        return transferDailyLimit;
    }

    public void setTransferDailyLimit(Integer transferDailyLimit) {
        this.transferDailyLimit = transferDailyLimit;
    }
}