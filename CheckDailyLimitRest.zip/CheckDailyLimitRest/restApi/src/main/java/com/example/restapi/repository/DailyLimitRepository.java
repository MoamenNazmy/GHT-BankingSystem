package com.example.restapi.repository;

import com.example.restapi.model.DailyLimit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface DailyLimitRepository extends JpaRepository<DailyLimit, Integer> {

    @Query("SELECT d.transferDailyLimit FROM DailyLimit d WHERE d.customerId = :customerId")
    Integer findDailyLimitByCustomerId(@Param("customerId") Integer customerId);
}