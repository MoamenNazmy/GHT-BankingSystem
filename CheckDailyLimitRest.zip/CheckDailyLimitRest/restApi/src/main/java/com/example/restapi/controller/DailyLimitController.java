package com.example.restapi.controller;

import com.example.restapi.service.DailyLimitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/limits")
public class DailyLimitController {

    @Autowired
    private DailyLimitService service;

    @GetMapping("/daily/{customerId}")
    public ResponseEntity<Integer> getDailyLimit(
            @PathVariable Integer customerId) {

        Integer limit = service.getDailyLimit(customerId);
        return limit != null
                ? ResponseEntity.ok(limit)
                : ResponseEntity.notFound().build();
    }
}