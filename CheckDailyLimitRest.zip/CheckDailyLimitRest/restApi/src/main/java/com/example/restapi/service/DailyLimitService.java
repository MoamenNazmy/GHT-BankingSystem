package com.example.restapi.service;

import com.example.restapi.repository.DailyLimitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DailyLimitService {

    @Autowired
    private DailyLimitRepository repository;

    public Integer getDailyLimit(Integer customerId) {
        return repository.findDailyLimitByCustomerId(customerId);
    }
}