--
-- PostgreSQL database dump
--

-- Dumped from database version 17rc1
-- Dumped by pg_dump version 17rc1

-- Started on 2025-05-19 16:54:52

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 223 (class 1255 OID 49951)
-- Name: transfer_funds(integer, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.transfer_funds(IN sender_id integer, IN receiver_id integer, IN transfer_amount numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
   
    UPDATE customer
    SET balance = balance - transfer_amount
    WHERE customer_id = sender_id;

    UPDATE customer
    SET balance = balance + transfer_amount
    WHERE customer_id = receiver_id;
    
END;
$$;


ALTER PROCEDURE public.transfer_funds(IN sender_id integer, IN receiver_id integer, IN transfer_amount numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 49907)
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    customer_name character varying(100) NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    account_type character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 49906)
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_customer_id_seq OWNER TO postgres;

--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 217
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- TOC entry 222 (class 1259 OID 49960)
-- Name: transfer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transfer (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    receiver_id integer NOT NULL,
    amount integer NOT NULL,
    update_balance integer
);


ALTER TABLE public.transfer OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 49959)
-- Name: transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transfer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transfer_id_seq OWNER TO postgres;

--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 221
-- Name: transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transfer_id_seq OWNED BY public.transfer.id;


--
-- TOC entry 220 (class 1259 OID 49928)
-- Name: transferdaily; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transferdaily (
    customer_id integer NOT NULL,
    transfer_daily_limit integer DEFAULT 0 NOT NULL,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transferdaily OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 49916)
-- Name: transferlimit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transferlimit (
    customer_id integer NOT NULL,
    transfer_limit integer DEFAULT 0 NOT NULL,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transferlimit OWNER TO postgres;

--
-- TOC entry 4709 (class 2604 OID 49910)
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- TOC entry 4717 (class 2604 OID 49963)
-- Name: transfer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfer ALTER COLUMN id SET DEFAULT nextval('public.transfer_id_seq'::regclass);


--
-- TOC entry 4876 (class 0 OID 49907)
-- Dependencies: 218
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, customer_name, balance, account_type, created_at, updated_at) FROM stdin;
1	moamen	35000	vip	2025-05-16 21:22:25.996538+03	2025-05-16 21:22:25.996538+03
2	mostafa	105000	saving	2025-05-18 03:52:02.191471+03	2025-05-18 03:52:02.191471+03
\.


--
-- TOC entry 4880 (class 0 OID 49960)
-- Dependencies: 222
-- Data for Name: transfer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transfer (id, sender_id, receiver_id, amount, update_balance) FROM stdin;
1	1	2	5000	15000
2	1	2	51000	19000
3	1	2	54322	15678
4	1	2	59999	10001
5	1	2	54000	16000
6	1	2	55555	14445
7	1	2	60000	10000
8	1	2	20000	35000
\.


--
-- TOC entry 4878 (class 0 OID 49928)
-- Dependencies: 220
-- Data for Name: transferdaily; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transferdaily (customer_id, transfer_daily_limit, last_updated) FROM stdin;
1	40000	2025-05-16 22:19:39.109917+03
2	30000	2025-05-18 23:18:23.775889+03
\.


--
-- TOC entry 4877 (class 0 OID 49916)
-- Dependencies: 219
-- Data for Name: transferlimit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transferlimit (customer_id, transfer_limit, last_updated) FROM stdin;
1	30000	2025-05-16 22:20:09.212316+03
2	20000	2025-05-18 23:17:40.042927+03
\.


--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 217
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 2, true);


--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 221
-- Name: transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transfer_id_seq', 8, true);


--
-- TOC entry 4719 (class 2606 OID 49915)
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4725 (class 2606 OID 49965)
-- Name: transfer transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfer
    ADD CONSTRAINT transfer_pkey PRIMARY KEY (id);


--
-- TOC entry 4723 (class 2606 OID 49934)
-- Name: transferdaily transferdaily_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transferdaily
    ADD CONSTRAINT transferdaily_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4721 (class 2606 OID 49922)
-- Name: transferlimit transferlimit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transferlimit
    ADD CONSTRAINT transferlimit_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4728 (class 2606 OID 49971)
-- Name: transfer fk_receiver; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfer
    ADD CONSTRAINT fk_receiver FOREIGN KEY (receiver_id) REFERENCES public.customer(customer_id);


--
-- TOC entry 4729 (class 2606 OID 49966)
-- Name: transfer fk_sender; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfer
    ADD CONSTRAINT fk_sender FOREIGN KEY (sender_id) REFERENCES public.customer(customer_id);


--
-- TOC entry 4727 (class 2606 OID 49935)
-- Name: transferdaily transferdaily_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transferdaily
    ADD CONSTRAINT transferdaily_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- TOC entry 4726 (class 2606 OID 49923)
-- Name: transferlimit transferlimit_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transferlimit
    ADD CONSTRAINT transferlimit_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


-- Completed on 2025-05-19 16:54:52

--
-- PostgreSQL database dump complete
--

