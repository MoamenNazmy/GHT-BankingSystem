package com.example.soap;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(targetNamespace = "http://otp.soap.example.com/")
public interface OTPService {
    @WebMethod
    int generateOTP(int customerId);
}
