package com.example.soap;

import javax.xml.ws.Endpoint;

public class OTPServicePublisher {
    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8085/otp", new OTPServiceImpl());
        System.out.println("SOAP OTP Service running at http://localhost:8085/otp?wsdl");
    }
}