package com.example.soap;

import javax.jws.WebService;
import java.util.Random;

@WebService(
        endpointInterface = "com.example.soap.OTPService",
        targetNamespace = "http://otp.soap.example.com/"
)
public class OTPServiceImpl implements OTPService {

    @Override
    public int generateOTP(int customerId) {
        int otp = 1000 + new Random().nextInt(9000);
        System.out.println("Generated OTP for customer " + customerId + ": " + otp);
        return otp;
    }
}
