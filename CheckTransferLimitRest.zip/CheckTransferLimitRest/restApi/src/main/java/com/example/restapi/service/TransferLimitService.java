package com.example.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.restapi.repository.TransferLimitRepository;

@Service
public class TransferLimitService {

    @Autowired
    private TransferLimitRepository transferLimitRepository;

    public Integer getTransferLimit(Integer customerId) {
        return transferLimitRepository.findTransferLimitByCustomerId(customerId);
    }
}