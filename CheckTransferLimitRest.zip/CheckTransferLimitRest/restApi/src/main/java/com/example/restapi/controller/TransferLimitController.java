package com.example.restapi.controller;

import com.example.restapi.service.TransferLimitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transfer-limits")
public class TransferLimitController {

    @Autowired
    private TransferLimitService transferLimitService;

    @GetMapping("/{customerId}")
    public ResponseEntity<Integer> getTransferLimit(
            @PathVariable Integer customerId) {

        Integer limit = transferLimitService.getTransferLimit(customerId);
        return limit != null
                ? ResponseEntity.ok(limit)
                : ResponseEntity.notFound().build();
    }
}