package com.example.restapi.model;

import javax.persistence.*;

@Entity
@Table(name = "transferlimit")
public class TransferLimit {

    @Id
    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name = "transfer_limit")
    private Integer transferLimit;

    // Getters and setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getTransferLimit() {
        return transferLimit;
    }

    public void setTransferLimit(Integer transferLimit) {
        this.transferLimit = transferLimit;
    }
}