package com.example.soap;

import javax.xml.ws.Endpoint;

public class BankServicePublisher {
    public static void main(String[] args) {
        // Load PostgreSQL JDBC driver
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("PostgreSQL JDBC Driver not found");
            e.printStackTrace();
            return;
        }

        Endpoint.publish("http://localhost:8082/bank", new BankServiceImpl());
        System.out.println("SOAP Banking Service running at http://localhost:8082/bank?wsdl");
    }
}