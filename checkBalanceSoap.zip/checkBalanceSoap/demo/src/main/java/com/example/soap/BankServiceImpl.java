package com.example.soap;

import javax.jws.WebService;
import java.sql.*;

@WebService(endpointInterface = "com.example.soap.BankService")
public class BankServiceImpl implements BankService {

    // Database connection parameters - configure these for your environment
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/bankingsystem";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "postgres";

    @Override
    public int getCustomerBalance(int customerId) {
        System.out.println("Attempting to connect to: " + DB_URL); // Debug line

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connection successful!"); // Debug line

            String sql = "SELECT balance FROM customer WHERE customer_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                System.out.println("Executing query: " + stmt.toString()); // Debug line

                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    int balance = rs.getInt("balance");
                    System.out.println("Found balance: " + balance); // Debug line
                    return balance;
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error:"); // Debug line
            e.printStackTrace();
        }
        System.out.println("Customer not found"); // Debug line
        return -1;
    }

    }



